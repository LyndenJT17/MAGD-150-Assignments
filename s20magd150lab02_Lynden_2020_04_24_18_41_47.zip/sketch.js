function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(51);
  noStroke();
  colorMode(RGB);
  fill(255,255,0);
  ellipse(300, 100, 55, 55);
  
  fill(0,255,255);
  ellipse(100, 100, 55, 55);
  
  colorMode(HSB);
  fill(360,100,100,100);
  ellipse(300, 300, 55, 55);
  
  fill('#C080FF');
  ellipse(100, 300, 55, 55);
  
  fill('orange');
  triangle(180, 225, 208, 170, 236, 225);
  
  fill('pink')
  quad(100,200,150,220,180,200,125,170);
  
  fill('#2BCF74');
  beginShape();
  vertex(157 + 50, 20);
  vertex(167+50,40);
  vertex(190+50,40);
  vertex(170+50,50);
  vertex(185+50, 75);
  vertex(157+50,60);
  vertex(130+50, 75);
  vertex(143+50,50);
  vertex(125+50,40);
  vertex(147+50, 40);
  endShape(CLOSE);
}


