let nature;
var nums = [];
function setup() {
  createCanvas(400, 400);
  nature = new Tree(200,200,50,60);//This calls for an object called tree to be created using the following parameters.
  for (var i = 0; i<4;i++){
    let x = 40* i;
  nums[i] =new Tree(x,300,50,50)}
}

function draw() {
  background(220);
  
  for (var i=0;i<4;i++){
    nums[i].display();
  }
  nature.display();
  
}

class Tree{
  constructor(x,y,w,h){ //The constructor takes the parameters and assigns them to this.(parameter).
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    
  }
 
  
  display(){ //Displays an tree like image.  The stump takes the parameters to create the stump.
    fill('brown');
  rect(this.x,this.y,this.w,this.h);
    
    //This part displays the leaves by creating a green triangle and putting it diectly over the stump.  The height of the leaves differs depending on the h parameter.
    fill('green');
    triangle(this.x-10,this.y, (this.w)/2+this.x, this.h, this.x+this.w+ 10,this.y );
  }
}

