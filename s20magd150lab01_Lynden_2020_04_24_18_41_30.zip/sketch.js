function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  strokeWeight(4);
stroke(100);
fill(199);
rect(100, 100, 200, 300);
line(100,100,195,50);
  line(195,50,300,100);
 rect(170, 350, 40, 50);
point(180, 380);
  point(200, 380);
  ellipse(190, 300, 100, 55);
  ellipse(190, 200, 55, 100);
}
