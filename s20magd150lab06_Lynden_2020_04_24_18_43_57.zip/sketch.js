l=20;
h=20;
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(200);
   drawperfCirc(300,300,20,20);
  findparameter(l,h);
  translate(100, 100);
  rotate(5);
  scale(2); //This Multiples the height and width of the square by 2.
   rect(0, 0, l, h); 
  
}

function findparameter(l,h)//This function prints the parameter of the square by taking the length and multiplying it by two and then adding it to the height multiplied by two
{
  var para = l*2 + h*2;
  print(para);
}

function drawperfCirc(x,y,z)//This function is made to create a perfect green circle.  It takes the x and y parameters to determine the location of the circle.  The z parameter is used to decide the radius
{fill('green');
ellipse(x,y,z,z);
findarea(z);//calls a function to find the area
}

function findarea(z)//finds area of the circle by taking the radius and taking it to the second power and multiplying by PI.  The function then prints the area
{
  area = PI * pow(z,2);
  print(area);
}