let r, g, b;
let button;
x=30;
y=60;
speed=0;
function setup() {
  createCanvas(400, 400);
  button = createButton("move");
  button.mouseClicked(movetri);
  button.size(30,40);
  button.position(185,300);
   r = 255;
  g = 255;
  b = 255;
}

function draw() {
  background(220);
   triangle(x,75,x+15,100,y,75)
x=x+speed
y=y+speed
    if (y>width||x<0){
  speed = speed*-1
  }

  fill(r, g, b, 127);
  rect(0,0,400,250)
  
  fill('gray')
  rect(150,270,90,110)
  
  fill('red')
  ellipse(170,290,20,20);
  
  rect(185,300,30,40);
  
  fill('black');
  text('color', 160, 295);
  
}

function mousePressed() {

  let d = dist(mouseX, mouseY, 170, 290);
  let x = dist;
  if (d < 10) {
   
    
    r = random(255);
    g = random (255);
    b = random(255);
    
    }
}
  
  

function movetri() {
  speed = 1;
 
}


