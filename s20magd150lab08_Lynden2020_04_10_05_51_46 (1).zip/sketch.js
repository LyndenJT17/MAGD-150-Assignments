var txt;
let img
let r, g, b;

function preload() {
  txt = loadStrings("Untitled document.txt");
 
}

function setup() {
  createCanvas(400, 400);
  textAlign('CENTER');
  createP(join(txt));
  loadImage(media.jpg);
            
}

function draw() {

  background(220);
  image(img,0,0);
  textSize(32);
  textFont('Helvetica');

  if (mouseIsPressed) {
    r = random(255);
    g = random(255);
    b = random(255);
    fill(r, g, b);
    image(img,0,0,10,10);



  }

  text('MAGD', 110, 30);
  textFont('Georgia');
  text('The Movie', 100, 70);




}