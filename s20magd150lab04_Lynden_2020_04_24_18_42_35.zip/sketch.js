x=30;
y=170;
speed=1;
function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
    x3=170;y3=75;
  
    
  fill('yellow');
  
  if (keyIsPressed ===true){
    speed=3;
  }
  triangle(x,75,x+65,220,y,75)

  for(let i=0; i<10; i++){
  triangle(x+i,75+i,x+65+i,220+i,y+i,75+i)}
    
    x=x+speed
y=y+speed
  if (y>width||x<0){
  speed = speed*-1
  }
  
  if (mouseIsPressed){
    fill('red')
  ellipse(x+50,150,30,30)
    ellipse(x+100,100,30,30)
  }
  
 
}
function mousePressed() {
  if (speed===1||speed===-1)
    speed=0;
  else
    speed=1;
}
