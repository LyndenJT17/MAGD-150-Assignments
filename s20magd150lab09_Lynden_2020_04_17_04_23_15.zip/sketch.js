var song;
var slider;
let video;
let input;
function preload(){
  song = loadSound("Numa Numa.mp3"); //loadSound loads a song which in this case is the song called "Numa Numa"
  sliderRate = createSlider(0, 3, 1, 0.01); //This creates a slider that has a scale between 0 and 3.  the default starts at 1 and increments by .01.
}

function setup() {
  createCanvas(1000, 1000);
  song.play();
  video = createVideo(['coffee.mp4']);//Creates a video about a cup of coffee
  video.hide();
  input= createInput();//Creates a textbox where you can enter a word or phrase
  input.position(500,500);//Changes the position of the textbox
}

function draw() {
  background(220);
  rect(100,0,200,400);
  song.rate(sliderRate.value());//The slider effects the rate of the song.
  image(video, 10,10);
}

function mousePressed(){
  video.loop();//This causes the video to replay endlessly
}