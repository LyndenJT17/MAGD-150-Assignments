
function setup() {
  width=500;
  height=400;
  createCanvas(width, height);
  x = 1.3;
  y=3.9;
  print(x +  " " + y);
  print(x+y);
  z=-3;
  print(abs(z));
  print(pow(z,2));
}

function draw() {
  background(244, 248, 252);
  let leftWall = 25;
  let rightWall = 75;
  let xc = constrain(mouseX, leftWall, rightWall);

  ellipse(xc,mouseY,x *75,20 - y);
  ellipse(mouseX,mouseY,x *75,20 - y);
  
}

